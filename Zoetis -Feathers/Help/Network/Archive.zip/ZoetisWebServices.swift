//  Zoetis -Feathers
//
//  Created by Suraj Kumar Panday on 08/11/19.
//  Copyright © 2019 Alok Yadav. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire
import MBProgressHUD

typealias CompletionBlock = (JSON, NSError?) -> Void

class ZoetisWebServices: BaseViewController {

    static let shared = ZoetisWebServices()
    var viewController = UIViewController()
// https://pv360.mobileprogramming.net/ProcessEvaluation/API/
    
    
 //    https://pv360.mobileprogramming.net/ProcessEvaluation/API/swagger/ui/index
    
    
    enum EndPoint: String {
        case login = "Token"
        case getPostingSessionList = "/ProcessEvaluation/API/api/PostingSession/GetPostingSessionListByUser?UserId="
        case getAllCustomerPE = "/ProcessEvaluation/API/api/Assessment/GetAllCustomer_PE"
        case getPEDosages = "/ProcessEvaluation/API/api/Assessment/GetPEDosages"
        //
        case getCustomerPE = "/ProcessEvaluation/API/api/Assessment/GetAssignedCustomerByUser?userId="
        case getSitesPE = "/ProcessEvaluation/API/api/Assessment/GetAssignedSitesByUser?userId="
        case getApproversPE = "/ProcessEvaluation/API/api/Assessment/GetTSRUser"
        case getEvaluator = "/ProcessEvaluation/API/api/Assessment/GetEvaluator?CountryId="
        case getVisitTypes = "/ProcessEvaluation/API/api/Assessment/GetReasonForVisitTypes"
        case getEvaluatorTypes = "/ProcessEvaluation/API/api/Assessment/GetEvaluationTypes"
        case getManufacturer = "/ProcessEvaluation/API/api/Assessment/GetManufacturer"
        case getBirdBreed = "/ProcessEvaluation/API/api/Assessment/GetBirdBreeds"
         case getEggs = "/ProcessEvaluation/API/api/Assessment/GetEggsPerFlat"
        case getVaccineManufacturer = "/ProcessEvaluation/API/api/Assessment/GetVaccineManufacturer"
        case getVaccineNames = "/ProcessEvaluation/API/api/Assessment/GetVaccineNames"
        case getDiluentManufacturer = "/ProcessEvaluation/API/api/Assessment/DiluentManufacturer"
        case getbagSizes = "/ProcessEvaluation/API/api/Assessment/GetBagSizeTypes"
        case getAmplePerBag = "/ProcessEvaluation/API/api/Assessment/GetAmpulePerBag"
        case getAmpleSizes = "/ProcessEvaluation/API/api/Assessment/GetAmpuleSizes"
        case getPostingAssessmentListByUserPE = "/ProcessEvaluation/API/api/Assessment/GetPostingAssessmentListByUser?UserId="
        case getPostingAssessmentImagesListByUserPE = "/ProcessEvaluation/API/api/AssessmentImage/GetPostingAssessmentImagesListByUser?UserId="
        case getModuleAssessmentCategoriesDetailsPE = "/ProcessEvaluation/API/api/Assessment/GetQuestionAnswerCategories?"
        case getAssessmentQuesInfoPE = "/ProcessEvaluation/API/api/Assessment/GetAssessmentInfosDetails"
        case postAddAttachmentDetails = "/ProcessEvaluation/API/api/Assessment/AddAssessment"
        case postAddScores = "/ProcessEvaluation/API/api/Assessment/AddScores"
          case postAddDayOfAgeAndInvoject = "/ProcessEvaluation/API/api/Assessment/AddInovojectDayOfAgeDetails"
       
        case postImagesBase64 = "/ProcessEvaluation/API/api/AssessmentImage/SaveAssessmentImagesDetails"
         //PVE--------------------
         ///PulletVaccineEvaluation/API
         //case getCustomerListPVE = "/PulletVaccineEvaluation/API/api/CustomerDetails/GetCustomerList?CountryId="
        /*
        case getCustomerListPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/CustomerDetails/GetAssignedCustomerByUser?userId="

         case getComplexPVEOld = "/PulletVaccineEvaluation/PVEWebAPI/api/ComplexDetails?customerId="
         case getComplexPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/ComplexDetails?"
         case getEvaluationTypePVE = "/PulletVaccineEvaluation/PVEWebAPI/api/EvaluationDetails/GetEvaluationType?Module_Id=2"
         case getEvaluationForPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/EvaluationDetails/GetEvaluationFor"
         //case getSiteIDNameDetailsPVE = "/ZoetisPV/API/api/SiteIDNameDetails"
         case getSiteIDNameDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/HatcherySitesDetails"
         case getBirdAgeDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/BirdAgeDetails"
        // case getBirdBreedsDetailsPVE = "/PulletVaccineEvaluation/API/api/BirdBreedsDetails"
        case getBirdBreedsDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/BirdBreedsDetails/GetBirdBreeds"

         case getHousingDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/HousingDetails"
        // case getAssignUserDetailPVE = "/PulletVaccineEvaluation/API/api/AssignUserDetails?Sub_Product_Id=1&User_Type_Id=2"
         case getAssignUserDetailPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/AssignUserDetails/GetAccountManagerList"
        // case getEvaluatorDetailPVE = "/PulletVaccineEvaluation/API/api/UserDetails/GetEvaluatorDetails?UserTypeId=2"
         case getEvaluatorDetailPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/UserDetails/GetEvaluator"
         case getModuleAssessmentCategoriesDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/ModuleAssessmentCategoriesDetails/GetModuleAssessmentCategoriesDetails?Module_Id=2"
         case getModuleAssessmentsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/ModuleAssessmentsDetails?Module_Cat_Id="
         case getSerotypeDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/SerotypeDetails"
         case getSurveyTypeDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/SurveyTypeDetails"
         case getSiteInjctsDetailssPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/SiteInjctsDetails"
         case getVaccineManDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/VaccineManDetails"
         //case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/API/api/VaccineNamesDetails"
        //case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/VaccineNamesDetails/GetVaccineNamesDetailsByManufacturerId?ManufacturerId=7"
        case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/VaccineNamesDetails/GetVaccineNamesDetails?api_key=GetPostingAssessmentListByUs"

        case getPostingAssessmentListByUser = "/PulletVaccineEvaluation/PVEWebAPI/api/AssignUserDetails/GetPostingAssessmentListByUser"

        case getPostingAssessmentImagesListByUser = "/PulletVaccineEvaluation/PVEWebAPI/api/AssignUserDetails/GetPostingAssessmentImagesListByUser?DeviceType=ios&api_key=GetPostingAssessmentListByUser"

        
        case postSNADetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/AssessmentDetails/CreateAssessmentDetails"
        case postScoreDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/AssessmentDetails/SaveAssessmentScoresDetails"
        case postSaveAssessmentImagesDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/AssessmentDetails/SaveAssessmentImagesDetails"

    */
         case getCustomerListPVE = "/PulletVaccineEvaluation/API/api/CustomerDetails/GetAssignedCustomerByUser?userId="

          case getComplexPVEOld = "/PulletVaccineEvaluation/API/api/ComplexDetails?customerId="
          case getComplexPVE = "/PulletVaccineEvaluation/API/api/ComplexDetails?"
          case getEvaluationTypePVE = "/PulletVaccineEvaluation/API/api/EvaluationDetails/GetEvaluationType?Module_Id=2"
          case getEvaluationForPVE = "/PulletVaccineEvaluation/API/api/EvaluationDetails/GetEvaluationFor"
          //case getSiteIDNameDetailsPVE = "/ZoetisPV/API/api/SiteIDNameDetails"
          case getSiteIDNameDetailsPVE = "/PulletVaccineEvaluation/API/api/HatcherySitesDetails"
          case getBirdAgeDetailsPVE = "/PulletVaccineEvaluation/API/api/BirdAgeDetails"
         // case getBirdBreedsDetailsPVE = "/PulletVaccineEvaluation/API/api/BirdBreedsDetails"
         case getBirdBreedsDetailsPVE = "/PulletVaccineEvaluation/API/api/BirdBreedsDetails/GetBirdBreeds"

          case getHousingDetailsPVE = "/PulletVaccineEvaluation/API/api/HousingDetails"
         // case getAssignUserDetailPVE = "/PulletVaccineEvaluation/API/api/AssignUserDetails?Sub_Product_Id=1&User_Type_Id=2"
          case getAssignUserDetailPVE = "/PulletVaccineEvaluation/API/api/AssignUserDetails/GetAccountManagerList"
         // case getEvaluatorDetailPVE = "/PulletVaccineEvaluation/API/api/UserDetails/GetEvaluatorDetails?UserTypeId=2"
          case getEvaluatorDetailPVE = "/PulletVaccineEvaluation/API/api/UserDetails/GetEvaluator"
          case getModuleAssessmentCategoriesDetailsPVE = "/PulletVaccineEvaluation/API/api/ModuleAssessmentCategoriesDetails/GetModuleAssessmentCategoriesDetails?Module_Id=2"
          case getModuleAssessmentsPVE = "/PulletVaccineEvaluation/API/api/ModuleAssessmentsDetails?Module_Cat_Id="
          case getSerotypeDetailsPVE = "/PulletVaccineEvaluation/API/api/SerotypeDetails"
          case getSurveyTypeDetailsPVE = "/PulletVaccineEvaluation/API/api/SurveyTypeDetails"
          case getSiteInjctsDetailssPVE = "/PulletVaccineEvaluation/API/api/SiteInjctsDetails"
          case getVaccineManDetailsPVE = "/PulletVaccineEvaluation/API/api/VaccineManDetails"
          //case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/API/api/VaccineNamesDetails"
         //case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/PVEWebAPI/api/VaccineNamesDetails/GetVaccineNamesDetailsByManufacturerId?ManufacturerId=7"
         case getVaccineNamesDetailsPVE = "/PulletVaccineEvaluation/API/api/VaccineNamesDetails/GetVaccineNamesDetails?api_key=GetPostingAssessmentListByUs"

         case getPostingAssessmentListByUser = "/PulletVaccineEvaluation/API/api/AssignUserDetails/GetPostingAssessmentListByUser"

         case getPostingAssessmentImagesListByUser = "/PulletVaccineEvaluation/API/api/AssignUserDetails/GetPostingAssessmentImagesListByUser?DeviceType=ios&api_key=GetPostingAssessmentListByUser"

         
         case postSNADetailsPVE = "/PulletVaccineEvaluation/API/api/AssessmentDetails/CreateAssessmentDetails"
         case postScoreDetailsPVE = "/PulletVaccineEvaluation/API/api/AssessmentDetails/SaveAssessmentScoresDetails"
         case postSaveAssessmentImagesDetailsPVE = "/PulletVaccineEvaluation/API/api/AssessmentDetails/SaveAssessmentImagesDetails"
        //case postSaveAssessmentImagesDetailsPVE = "/PulletVaccineEvaluation/API/api/AssessmentDetails/SaveAssessmentMultipleImagesDetails"

     /* */
        
        
        
///api/AssessmentDetails/CreateAssessmentDetails

        ///Microbial-----------------------------
        case getAllEnvironmentalLocationTypes = "/Microbial/API/api/MicrobialLocationTypes/AllMicrobiallEnvironmentalLocationTypes"
        case getAllBacterialLocationTypes = "/Microbial/API/api/MicrobialLocationTypes/AllMicrobialBacterialLocationTypes"
        case getAllCustomersMicrobial = "/Microbial/API/api/Customer/GetAllCustomersByUser?UserId="
        case getAllLocationValues = "/Microbial/API/api/MicrobialLocationValues/AllMicrobialLocationValues"
        case getAllHatcherySiteMicrobial =  "/Microbial/API/api/HatcherySites/GetAllHatcherySites"
        case getAllHatcheryReviewerMicrobial = "/Microbial/API/api/Users/GetAllTsrUsers"
        case getAllHatcheryConductTypesMicrobial = "/Microbial/API/api/MicrobialConductTypes/AllConductTypes"
        case getAllHatcheryPurposeOfSurveyURLPathMicrobial = "/Microbial/API/api/MicrobialSurveyPurpose/AllSurveyPurpose"
        case getAllHatcheryAllTransferTypeURLPathMicrobial = "/Microbial/API/api/MicrobialTransferTypes/AllMicrobialTransferTypes"
        case getAllHatcheryAllVisitTypeURLPathMicrobial = "/Microbial/API/api/MicrobialVisitTypes/GetAllVisitTypes"
        case getAllMicrobialSpecimenTypes = "/Microbial/API/api/MicrobialSpecimenType/AllMicrobialSpecimenTypes"
        case getAllMicrobialFeatherPulpTests = "/Microbial/API/api/MicrobialFeatherPulpTests/AllMicrobialFeatherPulpTests"
        case getAllMicrobialBirdTypes = "/Microbial/API/api/MicrobialBirdType/AllMicrobialBirdTypes"
        case syncEnvironmentalData = "/Microbial/API/api/MicrobialEnvironmentalDetails/AddMicrobialEnvironmentalDetails"
        case syncBacterialData = "/Microbial/API/api/MicrobialBacterialDetails/AddMicrobialBacterialDetails"
        case syncFeathurePulp = "/Microbial/API/api/MicrobialFeatherPulpDetails/AddMicrobialFeatherPulpDetails"
        case getSyncedReqData = "/Microbial/API/api/MicrobialDetails/GetDetailsByApiCount"
        case getAllCaseStatus = "/Microbial/API/api/MicrobialCaseStatus/AllCaseStatus"
        var latestUrl: String {
            return "\(Constants.Api.baseUrl)\(self.rawValue)"
        }
    }
}

extension NSError {

    convenience init(localizedDescription: String) {
        self.init(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: localizedDescription])
    }

    convenience init(code: Int, localizedDescription: String) {
        self.init(domain: "", code: code, userInfo: [NSLocalizedDescriptionKey: localizedDescription])
    }
}

extension ZoetisWebServices {



    func getPEDosagesListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let countryId = UserDefaults.standard.integer(forKey: "nonUScountryId")
           let url = EndPoint.getPEDosages.latestUrl
           //   print("GET SERVICE*** : getComplexListForPE ", url)
           getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllCustomerListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getAllCustomerPE.latestUrl
           //   print("GET SERVICE*** : getAllCustomerListForPE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
  
    func getCustomerListForPE( controller : UIViewController, countryID: String, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let id = UserDefaults.standard.integer(forKey: "Id")
           let url = EndPoint.getCustomerPE.latestUrl + String(id)
           getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getSitesListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let id = UserDefaults.standard.integer(forKey: "Id")
               let url = EndPoint.getSitesPE.latestUrl + String(id)
        //   let url = EndPoint.getSitesPE.latestUrl
           //   print("GET SERVICE*** : getSitesListForPE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getEvaluatorListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
              let countryId = UserDefaults.standard.integer(forKey: "nonUScountryId") 
              let url = EndPoint.getEvaluator.latestUrl + String(countryId)
              //   print("GET SERVICE*** : getEvaluatorListForPE ", url)
              getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getApproversListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                 let url = EndPoint.getApproversPE.latestUrl
                 getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getVisitTypesListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getVisitTypes.latestUrl
             //   print("GET SERVICE*** : getVisitTypesListForPE ", url)
             getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getEvaluatorTypesListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
            let url = EndPoint.getEvaluatorTypes.latestUrl
            getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getManufacturerListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
              let url = EndPoint.getManufacturer.latestUrl
              getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
      }
    
    func getBirdBreedListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                 let url = EndPoint.getBirdBreed.latestUrl
                 getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
         }
    
    func getEggsListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getEggs.latestUrl
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getVaccineManufacturerListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                  let url = EndPoint.getVaccineManufacturer.latestUrl
                  getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
     func getVaccineNamesListForPE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                    let url = EndPoint.getVaccineNames.latestUrl
                    getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
      }
    func getDiluentManufacturerList( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                      let url = EndPoint.getDiluentManufacturer.latestUrl
                      getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
        }
    
    func getBagSizes( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getbagSizes.latestUrl
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    func getAmplePerBag( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
          let url = EndPoint.getAmplePerBag.latestUrl
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
      }
    
    func getAmpleSizes( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getAmpleSizes.latestUrl
             getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
         }
    
    func getAssessmentCategoriesDetailsPE( controller: UIViewController,evalType: String,moduleID: String, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getModuleAssessmentCategoriesDetailsPE.latestUrl + "Module_Id=" + moduleID
             getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAssessmentQuesInfoPE( controller: UIViewController,evalType: String,moduleID: String, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
               let url = EndPoint.getAssessmentQuesInfoPE.latestUrl
               getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
      }
    
    func getPostingAssessmentListByUser( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        
          let Id =  UserDefaults.standard.value(forKey: "Id") as? Int ?? 0
        
          let url = EndPoint.getPostingAssessmentListByUserPE.latestUrl + String(Id) + "&DeviceType=ios"
            
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    //getPostingAssessmentImagesListByUserPE
    func getPostingAssessmentImagesListByUser( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
          
            let Id =  UserDefaults.standard.value(forKey: "Id") as? Int ?? 0
          
            let url = EndPoint.getPostingAssessmentImagesListByUserPE.latestUrl + String(Id) + "&DeviceType=ios"
              
            getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
      }
    
    
    

    func sendPostDataToServer(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             postRequest(showHud: true, showHudText: "", endPoint: EndPoint.postAddAttachmentDetails.latestUrl, controller: controller, parameters: parameters, headers: [:], completion: completion)
    }
    
    
    func sendScoresDataToServer(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        print("score data url ",EndPoint.postAddScores.latestUrl)
               postRequest(showHud: true, showHudText: "", endPoint: EndPoint.postAddScores.latestUrl, controller: controller, parameters: parameters, headers: [:], completion: completion)
    }
      
    func sendMultipleImagesBase64ToServer(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                postRequest(showHud: true, showHudText: "", endPoint: EndPoint.postImagesBase64.latestUrl, controller: controller, parameters: parameters, headers: [:], completion: completion)
     }
    
    
    func sendAddDayOfAgeAndInvoject(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
                postRequest(showHud: true, showHudText: "", endPoint: EndPoint.postAddDayOfAgeAndInvoject.latestUrl, controller: controller, parameters: parameters, headers: [:], completion: completion)
     }
    
    
    
//PVE--------------------

    func getVaccineNamesDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getVaccineNamesDetailsPVE.latestUrl
                print("GET SERVICE*** : getVaccineNamesDetailsPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getVaccineManDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getVaccineManDetailsPVE.latestUrl
                print("GET SERVICE*** : getVaccineManDetailsPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getSiteInjctsDetailssPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getSiteInjctsDetailssPVE.latestUrl
                print("GET SERVICE*** : getSiteInjctsDetailssPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getSurveyTypeDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getSurveyTypeDetailsPVE.latestUrl
                print("GET SERVICE*** : getSurveyTypeDetailsPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getSerotypeDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getSerotypeDetailsPVE.latestUrl
            print("GET SERVICE*** : getSerotypeDetailsPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    func getAssessmentCategoriesDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
             let url = EndPoint.getModuleAssessmentCategoriesDetailsPVE.latestUrl
            print("GET SERVICE*** : getAssessmentCategoriesDetailsPVE ", url)
          getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getCustomerListForPVE( controller: UIViewController, countryID: String, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let Id =  UserDefaults.standard.value(forKey: "Id") as? Int
        let url = EndPoint.getCustomerListPVE.latestUrl + String(Id ?? 0) + "&CountryId=\(countryID)"
        //let url = EndPoint.getCustomerListPVE.latestUrl + String(Id ?? 0)
           print("GET SERVICE*** : getCustomerListForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getComplexListForPVE( controller: UIViewController, countryID: String,  parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let customerID =  UserDefaults.standard.value(forKey: "Id") as? Int
      //  let url = EndPoint.getComplexPVE.latestUrl + "\(customerID ?? 0)" + "&CountryId=\(countryID)"
        //ZoetisPE/API/api/Assessment/GetComplex_PE?CountryId=
        let url = EndPoint.getComplexPVE.latestUrl + "CountryId=\(countryID)"
              print("GET SERVICE*** : getComplexListForPVE ", url)
           /*let accestoken = (UserDefaults.standard.value(forKey: "aceesTokentype") as? String)!
           let headers: HTTPHeaders = [
               "Authorization": accestoken,
               "Accept": "application/json"
           ]*/
        
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    ///// Start New Assessment
    
    func getBreedOfBirldsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getBirdBreedsDetailsPVE.latestUrl
          print("GET SERVICE*** : getBirdBreedsDetailsPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getEvaluationTypeForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getEvaluationTypePVE.latestUrl
              print("GET SERVICE*** : getEvaluationTypePVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getEvaluationForForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getEvaluationForPVE.latestUrl
              print("GET SERVICE*** : getEvaluationForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getSiteIdNameForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getSiteIDNameDetailsPVE.latestUrl
              print("GET SERVICE*** : getSiteIdNameForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getAgeOfBirdsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getBirdAgeDetailsPVE.latestUrl
              print("GET SERVICE*** : getAgeOfBirdsForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getBreedOfBirdsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getBirdBreedsDetailsPVE.latestUrl
              print("GET SERVICE*** : getBreedOfBirdsForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getHousingDetailsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getHousingDetailsPVE.latestUrl
              print("GET SERVICE*** : getHousingDetailsForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAssignUserDetailForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let countryId = UserDefaults.standard.integer(forKey: "nonUScountryId")
           let url = EndPoint.getAssignUserDetailPVE.latestUrl + "?CountryId=\(countryId)"
           //let url = EndPoint.getAssignUserDetailPVE.latestUrl
              print("GET SERVICE*** : getAssignUserDetailForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    func getEvaluatorDetailForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        
        let countryId = UserDefaults.standard.integer(forKey: "nonUScountryId")
        let url = EndPoint.getEvaluatorDetailPVE.latestUrl + "?CountryId=\(countryId)"

          // let url = EndPoint.getEvaluatorDetailPVE.latestUrl
              print("GET SERVICE*** : getEvaluatorDetailForPVE ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func GetPostingAssessmentListByUser( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getPostingAssessmentListByUser.latestUrl + "?DeviceType=ios"
            print("GET SERVICE*** : getPostingAssessmentListByUser ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func GetPostingAssessmentImagesListByUser( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getPostingAssessmentImagesListByUser.latestUrl
            print("GET SERVICE*** : getPostingAssessmentImagesListByUser ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    // PVE - Sync API ---- Start
    
    func postStartNewAssessmentDetailForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.postSNADetailsPVE.latestUrl
              print("Post SERVICE*** : postSNADetailsPVE ", url)

        postRequest(showHud: false, showHudText: "", endPoint: url, controller: controller, parameters: parameters, headers: [:], completion: completion)

    }
    
    func postScoreDetailsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.postScoreDetailsPVE.latestUrl
              print("Post SERVICE*** : postScoreDetailsPVE ", url)

        postRequest(showHud: false, showHudText: "", endPoint: url, controller: controller, parameters: parameters, headers: [:], completion: completion)

    }

    func postSaveAssessmentImagesDetailsForPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.postSaveAssessmentImagesDetailsPVE.latestUrl
              print("Post SERVICE*** : postSaveAssessmentImagesDetailsPVE ", url)

        postRequest(showHud: false, showHudText: "", endPoint: url, controller: controller, parameters: parameters, headers: [:], completion: completion)

    }
    
    // PVE - Sync API ---- End


//    func getAssessmentCategoriesDetailsPVE( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
//           let url = EndPoint.getModuleAssessmentCategoriesDetailsPVE.latestUrl
//           //   print("GET SERVICE*** : getAssessmentCategoriesDetailsPVE ", url)
//        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
//    }

    //-----------------Microbial-----------------------
    func getAllLocationTypeValues( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllLocationValues.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryAllTransferTypesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllEnvironmentalLocationTypes( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllEnvironmentalLocationTypes.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryAllTransferTypesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllBacterialLocationTypes( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllBacterialLocationTypes.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryAllTransferTypesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllMicrobialSpecimenTypes(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllMicrobialSpecimenTypes.latestUrl
        //   print("GET SERVICE*** : getAllMicrobialSpecimenTypes ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllMicrobialBirdTypes(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllMicrobialBirdTypes.latestUrl
        //   print("GET SERVICE*** : getAllMicrobialBirdTypes ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllMicrobialFeatherPulpTest(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllMicrobialFeatherPulpTests.latestUrl
        //   print("GET SERVICE*** : getAllMicrobialFeatherPulpTests ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllCaseStatus(controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllCaseStatus.latestUrl
        //   print("GET SERVICE*** : getAllMicrobialFeatherPulpTests ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllHatcheryAllVisitTypeForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcheryAllVisitTypeURLPathMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryAllVisitTypesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllCustomersForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let userId = UserDefaults.standard.value(forKey: "Id") as? Int
           let url = EndPoint.getAllCustomersMicrobial.latestUrl + "\(userId ?? 0)"
           //   print("GET SERVICE*** : getAllCustomersForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllSyncedRequisitionData( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
           let url = EndPoint.getSyncedReqData.latestUrl
           //   print("GET SERVICE*** : getAllCustomersForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func syncEnvironmentalData(reqType: RequisitionType, controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        var url = ""
        if reqType == .enviromental{
            url = EndPoint.syncEnvironmentalData.latestUrl
        }else if reqType == .bacterial{
            url = EndPoint.syncBacterialData.latestUrl
        }else{
            url = EndPoint.syncFeathurePulp.latestUrl
        }
        postRequest(showHud: false, showHudText: "", endPoint: url, controller: controller, parameters: parameters, headers: [:], completion: completion)
    }
    
    func getAllHatcherySitesForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcherySiteMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcherySitesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    
    func getAllHatcheryReviewerForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcheryReviewerMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryReviewerForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    
    func getAllHatcheryAllConductTypeForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcheryConductTypesMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryConductTypeForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    func getAllHatcheryAllSurveyPurposeForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcheryPurposeOfSurveyURLPathMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryPurposeOfSurveyForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }
    
    
    func getAllHatcheryAllTransferTypeForMicrobial( controller: UIViewController, parameters: JSONDictionary, completion: @escaping CompletionBlock) {
        let url = EndPoint.getAllHatcheryAllTransferTypeURLPathMicrobial.latestUrl
        //   print("GET SERVICE*** : getAllHatcheryAllTransferTypesForMicrobial ", url)
        getRequest(showHud: false, showHudText: "", controller: controller, endPoint: url, parameters: [:], headers: [:], completion: completion)
    }

    
    
    //Handlers

    func handleFailureBlock(error: NSError? = nil, json: JSON? = nil) {
            if error?.code == -1009 {
            viewController.noInternetConnection()
        } else if error?.code == 405 {
                          print("error in api 405")
            //  UserManager.instance.moveToLogin()
        } else if error?.code == 400 ||  error?.code == 401 {
            //let errorMSg = json?["error_description"]
                  print("error in api 6090")
            viewController.showAlertViewWithMessageAndActionHandler(message: "server response 400 || 401", actionHandler: nil)
        } else if error?.code == 405 {
                   print("error in api 456789")
            viewController.showAlertViewWithMessageAndActionHandler(message: "server response 405", actionHandler: nil)
        } else if error?.code == 402 {
                   print("error in api 456")
            viewController.showAlertViewWithMessageAndActionHandler(message: "server response 402", actionHandler: nil)
        } else {
            if error?.localizedDescription == "cancelled" {
                   print("error in api 22")
                return
            }
            viewController.showAlertViewWithMessageAndActionHandler(message: error?.localizedDescription ?? "Something went wrong.", actionHandler: nil)
        }
        dismissGlobalHUD(self.view)
    }

    func getRequest(showHud: Bool, showHudText: String, shouldErrorRequired: Bool = false, pageNumber: Int = 1, controller: UIViewController, endPoint: String, parameters: JSONDictionary, headers: JSONDictionary, completion: @escaping CompletionBlock) {
        viewController = controller
        ZoetisApiManager.GET(showHud: showHud, showHudText: showHudText, endPoint: endPoint, parameters: parameters, headers: headers, success: { (json) in
            self.handlecompletionResponse(json, shouldErrorRequired: shouldErrorRequired, completion: completion)
        }) { (error) in
            print("error in api 1")
           shouldErrorRequired ? completion(JSON([:]), error) : self.handleFailureBlock(error: error)
        }
    }

    func postRequest(showHud: Bool, showHudText: String, shouldErrorRequired: Bool = false, endPoint: String, controller: UIViewController, parameters: JSONDictionary, imageData: Data = Data(), imageKey: String = "", headers: JSONDictionary, completion: @escaping CompletionBlock) {
        viewController = controller
        ZoetisApiManager.POST(showHud: showHud, showHudText: showHudText, endPoint: endPoint, parameters: parameters, imageData: imageData, imageKey: imageKey, headers: headers, success: { (json) in
            self.handlecompletionResponse(json, shouldErrorRequired: shouldErrorRequired, completion: completion)
        }) { (error) in
                print("error in api 2")
           shouldErrorRequired ? completion(JSON([:]), error) : self.handleFailureBlock(error: error)
        }
    }

    func handlecompletionResponse(_ json: JSON, shouldErrorRequired: Bool = false, completion: @escaping CompletionBlock) {

        let jsonDic = json["error"].stringValue
  
        if jsonDic.count > 0 {
                      print("error in api 3")
             handleFailureBlock(json: json)
        } else {
             completion(json, nil)
        }

    }
    

}
